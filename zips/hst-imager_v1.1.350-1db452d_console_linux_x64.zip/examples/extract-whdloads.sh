#!/bin/sh

python extract-whdloads.py
read -r -p "Press any key to continue..." key