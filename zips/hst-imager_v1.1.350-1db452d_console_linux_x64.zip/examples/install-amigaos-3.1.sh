#!/bin/sh

python install-amigaos-3.1.py
read -r -p "Press any key to continue..." key