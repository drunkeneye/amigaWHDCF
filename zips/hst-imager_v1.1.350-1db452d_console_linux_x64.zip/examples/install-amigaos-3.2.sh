#!/bin/sh

python install-amigaos-3.2.py
read -r -p "Press any key to continue..." key