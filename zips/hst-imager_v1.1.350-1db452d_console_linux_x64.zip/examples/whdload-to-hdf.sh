#!/bin/sh

python whdload-to-hdf.py
read -r -p "Press any key to continue..." key